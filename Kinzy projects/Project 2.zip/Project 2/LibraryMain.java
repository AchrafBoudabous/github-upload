public class LibraryMain {
    public static void main(String[] args) {
        LibMember ali = new LibMember("Ali", "Yousif", 'm', 990109999, "33123455");
        LibMember mohammed = new LibMember("Mohammed", "Yousif", 'm', 990409898, "33193435");

        Book theLastWish = new Book("The Last Wish", "Andrzej Sapkowski", "", "superNOWA", 1993, "978-0-575-08244-1");
        Book swordOfDestiny = new Book("Sword of Destiny", "Andrzej Sapkowski", "", "superNOWA", 1992, "978-1-4732-1153-7");

        System.out.println("Is book 1 equal to book 2: "+ theLastWish.equals(swordOfDestiny));

        LibrarySystem system = new LibrarySystem();
        System.out.println("Is books list empty: "+ system.isEmptyBookList());
        System.out.println("Adding The Last Wish to the system: "+ system.addBook(theLastWish));
        System.out.println("Adding The Last Wish to the system: "+ system.addBook(theLastWish));
        System.out.println("Adding Sword Of Destiny to the system: "+ system.addBook(swordOfDestiny));
        System.out.println("Is books list empty: "+ system.isEmptyBookList());
        System.out.println(" ");

        System.out.println("Is members list empty: "+ system.isEmptyMembersList());
        System.out.println("Adding ali to the system: "+ system.addMember(ali));
        System.out.println("Adding mohammed to the system: "+ system.addMember(mohammed));
        System.out.println("Is members list empty: "+ system.isEmptyMembersList());
        System.out.println(" ");

        System.out.println("Return The Last Wish: "+ system.returnBook(theLastWish.getAccessionNum()) );
        System.out.println("Is The Last Wish issued: "+ system.isBookIssued(theLastWish.getAccessionNum()) );
        System.out.println(" ");

        System.out.println("Issue The Last Wish to Ali: "+ system.issueBook(theLastWish.getAccessionNum(), ali.getCprNum()) );
        System.out.println("Issue Sword Of Destiny to Mohammed: "+ system.issueBook(swordOfDestiny.getAccessionNum(), mohammed.getCprNum()) );
        system.printBooksIssued(mohammed.getCprNum());
        System.out.println(" ");

        System.out.println("Issue The Last Wish to Mohammed: "+ system.issueBook(theLastWish.getAccessionNum(), mohammed.getCprNum()) );
        System.out.println("Is The Last Wish issued: "+ system.isBookIssued(theLastWish.getAccessionNum()) );
        System.out.println(" ");

        System.out.println("Return The Last Wish: "+ system.returnBook(theLastWish.getAccessionNum()) );
        System.out.println("Issue The Last Wish to Mohammed: "+ system.issueBook(theLastWish.getAccessionNum(), mohammed.getCprNum()) );
        system.printBooksIssued(mohammed.getCprNum());
        System.out.println(" ");
    }
}
