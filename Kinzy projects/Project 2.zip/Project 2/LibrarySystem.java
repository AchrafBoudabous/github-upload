import java.util.*;

public class LibrarySystem {
    private LinkedList<Book> booksList;
    private LinkedList<LibMember> membersList;
    private int booksListSize;
    private int membersListSize;

    public LibrarySystem(){
        booksList               = new LinkedList<Book>();
        membersList             = new LinkedList<LibMember>();

        booksListSize           = 0;
        membersListSize         = 0;
    }

    public boolean addBook(Book element){
        if ( booksList.contains(element) )
            return false;
        booksList.add(element);
        booksListSize++;
        return true;
    }

    public int searchBook(long num){
        for (int n=0; n<booksListSize; n++){
            if (booksList.get(n).getAccessionNum() == num)
                return n;
        }
        return -1;
    }

    public boolean removeBook(long accessionNum){
        int bookIndex = searchBook(accessionNum);
        if (bookIndex != -1) {
            if (booksList.get(bookIndex).getIssuedTo() != null)
                return false;
            booksList.remove(bookIndex);
            booksListSize--;
            return true;
        }
        return false;
    }

    public boolean addMember(LibMember element){
        if ( membersList.contains(element) )
            return false;
        membersList.add(element);
        membersListSize++;
        return true;
    }

    public int searchMember(long cpr){
        for (int n=0; n<membersListSize; n++){
            if (membersList.get(n).getCprNum() == cpr)
                return n;
        }
        return -1;
    }

    public boolean removeMember(long cpr){
        int memberIndex = searchMember(cpr);
        if (memberIndex != -1){
            if (membersList.get(memberIndex).getNumBooksIssued() == 0)
                return false;
            membersList.remove(memberIndex);
            membersListSize--;
            return true;
        }
        return false;
    }

    public boolean isEmptyBookList(){
        return (booksListSize == 0);
    }

    public boolean isEmptyMembersList(){
        return (membersListSize == 0);
    }

    public int sizeBooksList(){
        return booksListSize;
    }

    public int sizeMembersList(){
        return membersListSize;
    }

    public boolean issueBook(long accessionNum, long cpr){
        int bookIndex = searchBook(accessionNum);
        if (bookIndex == -1)
            return false;

        int memberIndex = searchMember(cpr);
        if (memberIndex == -1)
            return false;

        Book book = booksList.get(bookIndex);
        if (book.getIssuedTo() != null)
            return false;

        LibMember member = membersList.get(memberIndex);
        if (member.getNumBooksIssued() >= 10)
            return false;

        book.setIssuedTo(member);
        member.addBook(book);
        return true;
    }

    public boolean returnBook(long accessionNum){
        int bookIndex = searchBook(accessionNum);
        if (bookIndex == -1)
            return false;

        Book book = booksList.get(bookIndex);
        LibMember member = book.getIssuedTo();
        if (member == null)
            return false;

        member.removeBook(book);
        book.setIssuedTo(null);
        return true;
    }

    public void printBooksIssued(long cpr){
        int memberIndex = searchMember(cpr);
        if (memberIndex != -1){
            ArrayList<Book> books = membersList.get(memberIndex).getBooksIssued();

            int n = 1;
            for (Book x: books){
                System.out.println("BOOK #"+ n);
                System.out.println(x);
                System.out.println("----------------------");
                n++;
            }
        }
    }

    public boolean isBookIssued(long accessionNum){
        int bookIndex = searchBook(accessionNum);
        if (bookIndex == -1)
            return false;

        return ( booksList.get(bookIndex).getIssuedTo() != null );
    }
}
