public class Book {
    private String title;
    private String author1;
    private String author2;
    private String publisher;
    private int yearPublication;
    private String isbn;
    private long accessionNum;
    private LibMember issuedTo;

    private static long acNum = 1001;

    public Book(){
        this("", "", "", "", 0, "");
    }

    public Book(String title, String author1, String author2, String publisher, int yearPublication, String isbn){
        this.title                  = title;
        this.author1                = author1;
        this.author2                = author2;
        this.publisher              = publisher;
        this.yearPublication        = yearPublication;
        this.isbn                   = isbn;
        this.accessionNum           = acNum;
        acNum++;
        this.issuedTo               = null;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor1() {
        return author1;
    }

    public String getAuthor2() {
        return author2;
    }

    public String getPublisher() {
        return publisher;
    }

    public int getYearPublication() {
        return yearPublication;
    }

    public String getIsbn() {
        return isbn;
    }

    public long getAccessionNum() {
        return accessionNum;
    }

    public LibMember getIssuedTo() {
        return issuedTo;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor1(String author1) {
        this.author1 = author1;
    }

    public void setAuthor2(String author2) {
        this.author2 = author2;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public void setYearPublication(int yearPublication) {
        this.yearPublication = yearPublication;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public void setAccessionNum(long accessionNum) {
        this.accessionNum = accessionNum;
    }

    public void setIssuedTo(LibMember issuedTo) {
        this.issuedTo = issuedTo;
    }

    public boolean equals(Book comp){
        if ( title.equals(comp.title) && author1.equals(comp.author1) && author2.equals(comp.author2) && publisher.equals(comp.publisher) && isbn.equals(comp.isbn) && yearPublication == comp.yearPublication )
            return true;
        return false;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", author1='" + author1 + '\'' +
                ", author2='" + author2 + '\'' +
                ", publisher='" + publisher + '\'' +
                ", yearPublication=" + yearPublication +
                ", isbn='" + isbn + '\'' +
                ", accessionNum=" + accessionNum +
                ", issuedTo=" + issuedTo.toString() +
                '}';
    }
}
