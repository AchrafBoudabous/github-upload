import java.util.ArrayList;
import java.util.Arrays;

public class LibMember {
    private String firstName;
    private String lastName;
    private char gender;
    private long cprNum;
    private String teleNum;
    private ArrayList<Book> booksIssued;
    private int numBooksIssued;

    public LibMember(){
        this("", "", '0', 0, "");
    }

    public LibMember(String firstName, String lastName, char gender, long cprNum, String teleNum){
        this.firstName      = firstName;
        this.lastName       = lastName;
        this.gender         = gender;
        this.cprNum         = cprNum;
        this.teleNum        = teleNum;

        booksIssued         = new ArrayList<Book>(10);
        numBooksIssued      = 0;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public long getCprNum() {
        return cprNum;
    }

    public ArrayList<Book> getBooksIssued(){
        return booksIssued;
    }

    public void setCprNum(long cprNum) {
        this.cprNum = cprNum;
    }

    public String getTeleNum() {
        return teleNum;
    }

    public void setTeleNum(String teleNum) {
        this.teleNum = teleNum;
    }


    public int getNumBooksIssued() {
        return numBooksIssued;
    }

    public void setNumBooksIssued(int numBooksIssued) {
        this.numBooksIssued = numBooksIssued;
    }

    public void addBook(Book book){
        booksIssued.add(book);
        numBooksIssued++;
    }

    public void removeBook(Book book){
        booksIssued.remove(book);
        numBooksIssued--;
    }

    public boolean equals(LibMember comp){
        if ( firstName.equals(comp.firstName) && lastName.equals(comp.lastName) && teleNum.equals(comp.teleNum) && gender == comp.gender && cprNum == comp.cprNum )
            return true;
        return false;
    }

    @Override
    public String toString() {
        return "LibMember{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", gender=" + gender +
                ", cprNum=" + cprNum +
                ", teleNum='" + teleNum + '\'' +
                ", numBooksIssued=" + numBooksIssued +
                '}';
    }
}
