
import java.util.Scanner;

public class Registration {

    public static void main(String[] args) {



        Scanner read =new  Scanner(System.in);

        Roster firstTerm = new Roster();

        Course course;

        int ChooseNumber,credits,section;

        String courseNumber, courseName;

        long id=0;



        do{

            System.out.println( "---------------------------------------------------\n"+

        " ..............welcome to our registration system .............\n"+

         "Choose number of the following table: \n"+

         "Add student press \"1\".\t     Delete student press \"2\".\n"+

          "Add course press \"3\".\t     Delete course press \"4\". \n"+

          "Print student details \"5\".\t End the program \"0\".\n"+

           "--------------------------------------------------------");



            ChooseNumber=read.nextInt();


/*we have 6 cases (options)for the user;*/


            switch(ChooseNumber){

/*case1: press 1 to add student*/
                case 1:

                    System.out.println("Add student - Enter student id, first name, last name, email and gender. ");

                    id=read.nextLong();

                    String first=read.next(),

                            last=read.next(),

                            email=read.next();

                    char gender =read.next().toUpperCase().charAt(0);

                    student addStudent = new student(id,first,last,email,gender);

                    firstTerm.addStudent(addStudent);

                    break;
                    /*cse2: press 2 to delete student*/

                case 2:

                    System.out.println("Delete student- Enter student id.");

                    id=read.nextLong();

                    firstTerm.deleteStudent(id);

                    break;
                    /*case3:press 3 to add course*/

                case 3:

                    System.out.println("Add course -Enter student id,course number, course name, credits, and section.");

                    id=read.nextLong();

                    courseNumber = read.next();

                            courseName = read.next();

                        credits=read.nextInt();

                        section = read.nextInt();

                     course = new Course(courseNumber,courseName,credits,section);

                    firstTerm.addCourse(course,id);

                    break;

                 /*case 4: press 4 to delete course*/
                case 4:

                    System.out.println("Delete course-Enter student id,course number, course name, credits, and section.");

                    id=read.nextLong();

                    courseNumber = read.next();

                            courseName = read.next();

                            credits=read.nextInt();

                             section = read.nextInt();

                    course = new Course(courseNumber,courseName,credits,section);

                    firstTerm.deleteCourse(course,id);



                break;


                /*case 5 : press 5 to print student details*/
                case 5:

                    System.out.println("Print student detail - Enter student id.");

                    id=read.nextLong();

                    firstTerm.printStudentDetails(id);

                    break;

                 /*case 6 : press 0 to end the program*/
                case 0:

                    System.out.println("End of the program!Thank you");

                    ChooseNumber=0;

                    break;

                default:

                    System.out.println("The number you Enter is not correct.");

            }

        }
        /*while loop to continue working the program till the user enters 0 to end the program*/

        while(ChooseNumber != 0);



    }



}

