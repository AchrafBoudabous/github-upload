public class Course {
	//data members
	/*
	*String courseNum,courseName
	*int credits,section */

    private String courseNum,courseName;

    private int credits,section;
//constructors
/*Default constructor*/


    public Course(){

        courseName="No Name";

        courseNum="unknown";

        credits=0;

        section=0;



    }
    /*Counstructor with 4 parameters*/



    public Course(String courseNum, String courseName, int credits, int section) {

        this.courseNum = courseNum;

        this.courseName = courseName;

        this.credits = credits;

        this.section = section;

    }

/*get method for courseNum*/

    public String getCourseNum() {

        return courseNum;

    }


/*set method for courseNum*/
    public void setCourseNum(String courseNum) {

        this.courseNum = courseNum;

    }


/*get method for courseName*/
    public String getCourseName() {

        return courseName;

    }


/*set method for Course name*/
    public void setCourseName(String courseName) {

        this.courseName = courseName;

    }


/*get method for credits*/
    public int getCredits() {

        return credits;

    }


/*set method for credits*/
    public void setCredits(int credits) {

        this.credits = credits;

    }


/*get method for section*/
    public int getSection() {

        return section;

    }


/*set method for section*/
    public void setSection(int section) {

        this.section = section;

    }


/*method equals*/
    public boolean equals(Course secondCourse){



        boolean check=(this.courseName.equalsIgnoreCase(secondCourse.courseName)&&

        this.courseNum.equalsIgnoreCase(secondCourse.courseNum)&&

        this.credits==secondCourse.credits&& this.section==secondCourse.section);



        return check;

    }


/*method toString*/
    public String toString(){

        return "Course Name: "+courseName+", Course Number: "+courseNum+ ", Section: "

                +section + ", Credits: "+credits +".";

    }

}

