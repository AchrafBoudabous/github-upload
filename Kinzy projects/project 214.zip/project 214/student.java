public class student extends Course{
//data members
	/*
	*long idNum
	*String firstName,lastName,email
	*char gender
	*/
    private long idNum;

    private String firstName,lastName,email;

    private char gender;

    protected ArrayList<Course> coursesRegistered ;

/*default constructor*/

    public student(){

        idNum=0000;

        firstName="unknown";

        lastName="unknown";

        email="unkwnown";

        gender='a';

        coursesRegistered= new ArrayList<>();



    }
    /*constructor with 5 parameters*/



    public student(long idNum, String firstName, String lastName, String email, char gender) {

        this.idNum = idNum;

        this.firstName = firstName;

        this.lastName = lastName;

        this.email = email;

        this.gender = gender;

        coursesRegistered= new ArrayList<>();

    }

/*get method for IdNum */

    public long getIdNum() {

        return idNum;

    }


/*set method for IdNum*/
    public void setIdNum(long idNum) {

        this.idNum = idNum;

    }


/*get method for firstName*/
    public String getFirstName() {

        return firstName;

    }


/*set method for firstname*/
    public void setFirstName(String firstName) {

        this.firstName = firstName;

    }


/*get method for lastName*/
    public String getLastName() {

        return lastName;

    }


/*set method for lastName*/
    public void setLastName(String lastName) {

        this.lastName = lastName;

    }


/*get method for email */
    public String getEmail() {

        return email;

    }


/*set method for email*/
    public void setEmail(String email) {

        this.email = email;

    }


/*get method for gender */
    public char getGender() {

        return gender;

    }


/*set method for gender*/
    public void setGender(char gender) {

        this.gender = gender;

    }


/*get method for coursesRegistered*/
    public Course getCoursesRegistered(int index) {

        return coursesRegistered.get(index);

    }


/*set method for CoursesRegistered*/
    public void setCoursesRegistered(int index,Course coursesRegistered) {

        this.coursesRegistered.set(index,coursesRegistered);

    }

/*method equals compares two objects of type Student based on their idNums*/
    public boolean equals(student secondStudent){

        return this.idNum==secondStudent.idNum;

    }

/*method printCoursesRegistered to printl all registered courses*/
    public void printCoursesRegistered(){

        for (int i = 0;i <coursesRegistered.size();i++)

            System.out.println(coursesRegistered.get(i));

    }



}//end of the class


