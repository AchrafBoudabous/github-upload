
import java.util.LinkedList;

public class Roster  extends student{
//data members
/*LinkedList<student> studentsList
*int size */
    private LinkedList<student> studentsList;

    private int size;


/*Constructor without any parameter Creates studentsList as empty list and initialize size to 0*/

    public Roster(){

        studentsList = new LinkedList<>();

        size=0;

    }


/* addStudent method inserts a new Student object at the end of the studentsList
Object of type student is passed as parameter. If the object already exists in the list,
then do not add the object and return false, else return true after successfully adding the object*/

    public boolean addStudent(student studentObj){

        if(isEmpty()) {

            studentsList.addFirst(studentObj);

            size++;

        }

        if(studentsList.contains(studentObj))

            return false;

        studentsList.addLast(studentObj);

        size++;

        return true;

    }


/*deleteStudent is a method that deletes object from the  studentsList
The idNum of the Student is passed as parameter. If the object is not found in the studentsList,
then the object cannot be deleted and the method returns false, else the method returns true,
after successfully deleting the object.*/
    public boolean deleteStudent(long idNum){

            if(isEmpty())

                return false;



                int studentIndex = searchStudent(idNum);

                if(studentIndex != -1){

                studentsList.remove(studentIndex);

                size--;

                return true;
                }//end of if





            return false;



    }






/* searches the studentsList by idNum, passed as parameter . If the object is found,
it returns its location in the studentsList,
else returns -1*/

    public int searchStudent(long idNum){

        for(int i = 0; i<size ;i++){

            if(studentsList.get(i).getIdNum()==idNum)

                return i;

        }//end of for

            return -1;

    }//end of searchStudent


/* returns true, if the studentsList is empty, else returns false */

    public boolean isEmpty(){

       if(studentsList.isEmpty())
       return true;
       else
       return false ;

    }

    /*listSize method which returns the instance size*/

    public int listSize(){
		return size;
		}

/*addCourse method accepts an object of type Course as the first parameter and the idNum of the Student as the second parameter*/

    public void addCourse(Course course,long idNum)

    {

        boolean CourseAvailable=false;

        int totalCredits=0;

        int studentIndex=searchStudent(idNum);



        if(studentIndex ==-1){



  System.out.println("The student not available in roster");



        }else if (studentsList.get(studentIndex).coursesRegistered.isEmpty()) {



            studentsList.get(studentIndex).coursesRegistered.add(course);

            System.out.println("\""+course.getCourseName()+"\" added to course registered");



        }else{ //student found in roster

            int sizeOfCourse = studentsList.get(studentIndex).coursesRegistered.size();



           for(int i = 0; i < sizeOfCourse ;i++){



               if(studentsList.get(studentIndex).getCoursesRegistered(i).equals(course))

               {

                   CourseAvailable=true;

                   System.out.println("The coures is available!");

                   break;

               }



                    totalCredits+=studentsList.get(studentIndex).getCoursesRegistered(i).getCredits();





                }//for

               if(!CourseAvailable) {

                    totalCredits+= course.getCredits();

                   if (totalCredits > 18) {

                       System.out.println("Maximum credits is 18, the total credits will be \""

                               + totalCredits + "\" if the course added.");

                   } else {

                       studentsList.get(studentIndex).coursesRegistered.add(course);

                       System.out.println("\""+course.getCourseName()+"\" added to course registered");

                   }

               }//end of !courseAvailable

        }//close student found in roster



    }//end of method add course



/*deleteCourse accepts an object of type Course as the first parameter and the idNum of the Student as the second parameter and
it deletes a course by conditions */

    public void deleteCourse(Course course,long ID){



        int studentIndex=searchStudent(ID);

        if(studentIndex ==-1){

            System.out.println("The student not available in roster!");

        }else if (studentsList.get(studentIndex).coursesRegistered.isEmpty())

         System.out.println("Course registered is empty!");

        else{

            boolean courseAvailable=false;

            int sizeOfCourses=studentsList.get(studentIndex).coursesRegistered.size();

            for(int i = 0 ; i < sizeOfCourses; i++){

                if(studentsList.get(studentIndex).getCoursesRegistered(i).equals(course)){

                    studentsList.get(studentIndex).coursesRegistered.remove(i);

                    courseAvailable=true;

                    System.out.println("\""+course.getCourseName()+

                            "\" has been removed from courses registered");

                    break;

                }//if

            }//for

            if(!courseAvailable)

                System.out.println("Course not available in course registered!");

        }



    }//end of deleteCourse

    /*accepts idNum of Student as a parameter and prints all the details of the Student and also
    all the details of the courses in which the Student is registered*/

    public void printStudentDetails(long ID){

        int studentIndex=searchStudent(ID);

        if(studentIndex == -1){

            System.out.println("The student is not found , student is not registered in any courses!!!");

        }else
        {
			//student found

            System.out.println("Student id: " + studentsList.get(studentIndex).getIdNum() +

                    ".\nStudent name : " + studentsList.get(studentIndex).getFirstName() +

                    " " + studentsList.get(studentIndex).getLastName() +

                    ".\nStudent email: " + studentsList.get(studentIndex).getEmail() +

                    ".\nStudent Gender: " + studentsList.get(studentIndex).getGender());

            if (!studentsList.get(studentIndex).coursesRegistered.isEmpty())
            { //if there are courses

                System.out.println("*****Courses registered***** ");

                studentsList.get(studentIndex).printCoursesRegistered();

                System.out.println("*****end*****");

            }//if there are courses

            else{

                System.out.println("No course registered to this student ID: "+ID+" .");

            }



        }//student found

    }//printStudentDetails



}//class

