import java.util.ArrayList;

/**
 * Created by user on 15/04/2018.
 */
public class Student {
    private long idNum;
    private String firstName;
    private String LastName;
    private char Gender;
    private String email;
    private ArrayList<Course>coursesRegistered;

    public Student(){
        idNum=000000;
        firstName ="no name";
        LastName="no name ";
        Gender='0';
        email="no email";
        coursesRegistered = new ArrayList<Course>();
    }

    public Student(long idNum, String firstName, String lastName, char gender, String email) {
        this.idNum = idNum;
        this.firstName = firstName;
        LastName = lastName;
        Gender = gender;
        this.email = email;
        coursesRegistered = new ArrayList<Course>();
    }

    public long getIdNum()
    {

        return idNum;
    }

    public void setIdNum(long idNum)
    {
        this.idNum = idNum;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return LastName;
    }

    public void setLastName(String lastName)
    {
        LastName = lastName;
    }

    public char getGender()
    {
        return Gender;
    }

    public void setGender(char gender)
    {
        Gender = gender;
    }

    public String getEmail()
    {
        return email;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public ArrayList<Course> getCoursesRegistered()
    {
        return coursesRegistered;
    }

    public void setCoursesRegistered(ArrayList<Course> coursesRegistered)
    {
        this.coursesRegistered = coursesRegistered;
    }

    public boolean equal(Student st1)
    {
        if(this.idNum==st1.idNum)
        {
            return true;
        }
        else
            return false;
    }
    public void printCoursesRegistered(){
        System.out.println(coursesRegistered);
    }
}
