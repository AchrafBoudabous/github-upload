// - malak mohammed janahi  20174248
// - mariam qassim  20167929
// - ghada ahmed al rabia 20166127
import java.util.ArrayList;
import java.util.Scanner;

public class Registration
{
    static Scanner kbd = new Scanner(System.in);
    static Roster R = new Roster();
    static ArrayList<Course> Clist = new ArrayList<Course>();
    static ArrayList<Student> SList = new ArrayList<Student>();

    public static void main(String[] args) {
        int CNum = 0;
        System.out.println("Enter the number of courses you want to create :");
        CNum=kbd.nextInt();

        for (int i =0; i<CNum;i++)
        {
            System.out.println("Course "+ (i+1) +" :");
            CreateCR();
            System.out.println("--------------------");
        }
        System.out.println("Enter the number of students you want to add to the list");
        int SNum = 0;
        SNum = kbd.nextInt();
        for(int i = 0; i<SNum; i++)
        {
            System.out.println("Student "+ (i+1) +" :");
            CreateAndAddST();
            System.out.println("---------------");
        }
        boolean exit = false;
        System.out.print("Type a command ("+"h"+" for help) : ");
        while (!exit)
        {
            String Command;
            Command = kbd.nextLine();
            Command = Command.toLowerCase();
            switch (Command)
            {
                case "add course" : // add course to student case
                case "addcourse" :
                    CourseToStudent("add");
                    System.out.println("--------------------");
                    break;
                case "remove course" : // delete course from student
                case "removecourse" :
                    CourseToStudent("delete");
                    System.out.println("--------------------");
                    break;
                case "delete student": // delete student
                case "deltestudent" :
                    if(R.isEmpty())
                    {
                        System.out.println("Students list is empty !!!");
                        System.out.println("--------------------");
                        break;
                    }
                    System.out.println("Enter student ID : ");
                    long id =kbd.nextLong();
                    int j = R.searchStudent(id);
                    if(R.deleteStudent(id))
                    {
                        SList.remove(j);
                        System.out.println("Student successfully deleted");
                        System.out.println("--------------------");
                    }
                    else
                    {
                        System.out.println("Student not found !!!");
                        System.out.println("--------------------");
                    }
                    break;
                case "print student" : // print student details
                case "printstudent":
                    if(R.isEmpty())
                    {
                        System.out.println("Students list is empty !!!");
                        System.out.println("--------------------");
                        break;
                    }
                    System.out.println("Enter student ID : ");
                    long ID = kbd.nextLong();
                    if(R.searchStudent(ID)==-1)
                    {
                        System.out.println("Student not found !!!");
                        System.out.println("--------------------");
                        break;
                    }
                    R.printStudentDetails(ID);
                    System.out.println("--------------------");
                    break;
                case "print students" : // print all students details
                case "printstudents" :
                    if(R.isEmpty())
                    {
                        System.out.println("Students list is empty !!!");
                        System.out.println("--------------------");
                        break;
                    }
                    for(int i = 0; i<R.listSize();i++)
                    {
                        int index = R.searchStudent(SList.get(i).getIdNum());
                        R.printStudentDetails(SList.get(index).getIdNum());
                        System.out.println("--------------------");
                    }
                    break;
                case "courses" :
                    if(Clist.isEmpty())
                    {
                        System.out.println("You have't created any course !!!");
                        System.out.println("--------------------");
                        break;
                    }
                    for(int i =0; i<Clist.size();i++)
                    {
                        System.out.println(Clist.get(i).getCourseNum().toUpperCase());
                    }
                    System.out.println("--------------------");
                    break;
                case "add new student":
                    CreateAndAddST();
                    System.out.println("--------------------");
                    break;
                case "create course":
                case "createcourse" :
                    CreateCR();
                    System.out.println("--------------------");
                    break;
                case "h" :
                    Help();
                    break;
                case "exit" ://exite case
                case "0" :
                    exit = true;
                    break;
            }
            if(!exit && !Command.equals(""))System.out.print("Type a command ("+"h"+" for help) : ");
        }
    }
    public static void CreateCR()
    {
        System.out.print("Enter course code : ");
        String Code = kbd.next();
        for(int i =0; i<Clist.size();i++)
        {
            if(Clist.get(i).getCourseNum().equalsIgnoreCase(Code))
            {
                System.out.println("Error : Course already exist in the list !!!");
                return;
            }
        }
        System.out.print("course name : ");
        String name = kbd.next();
        System.out.print("course credit :\t");
        int credit = kbd.nextInt();
        System.out.print("section number :\t");
        int section = kbd.nextInt();
        Course course = new Course(Code,name,credit,section);
        Clist.add(course);
    }
    public static void CreateAndAddST()
    {
        System.out.print("Enter student id (Numbers only) :\t ");
        long id=kbd.nextLong();
        if(R.searchStudent(id)!=-1)
        {
            System.out.println("Student already exist !!!");
            return;
        }
        System.out.print("first name :  ");
        String first=kbd.next();
        System.out.print("last name :  ");
        String last=kbd.next();
        System.out.print("gender(M or F) :\t ");
        char gender=kbd.next().charAt(0);
        System.out.print("email :\t ");
        String Email=kbd.next();
        Student ST = new Student(id,first,last,gender,Email);
        R.addStudent(ST);
        SList.add(ST);
    }
    public static void CourseToStudent(String command)
    {
        if(R.isEmpty())
        {
            System.out.println("Students list is empty !!!");
            return;
        }else if(Clist.isEmpty())
        {
            System.out.println("You haven't created any course !!!");
            return;
        }
        System.out.print("Enter student ID(Numbers only) :\t");
        long ID = kbd.nextLong();
        int index = R.searchStudent(ID);
        if(index==-1)
        {
            System.out.println("Student not found !!!");
            return;
        }
        System.out.println("Type course code :\t");
        String CRSCode = kbd.next();
        Course CR = new Course();
        boolean Found = false;
        for (int i =0; i<Clist.size();i++)
        {
            if(Clist.get(i).getCourseNum().equalsIgnoreCase(CRSCode))
            {
                CR = Clist.get(i);
                Found = true;
            }
        }
        if(Found)
        {
            if(command.equalsIgnoreCase("add"))
            {
                if(R.addCourse(CR,ID))
                {
                    System.out.println("Course Successfully added");
                }else
                    System.out.println("Error : adding the course !!");
            } else if (command.equalsIgnoreCase("delete"))
            {
                R.DeleteCourse(CR,ID);
                System.out.println("Course Successfully deleted");
            }
        }
        else
        {
            System.out.println("Course not Found !!!");
        }
    }
    public static void Help()
    {
        System.out.println("--------------------");
        System.out.println("- add course --> to add a course to student");
        System.out.println("- remove course --> to remove a course from student ");
        System.out.println("- delete student --> to delete a student from list  ");
        System.out.println("- print student --> to print student details");
        System.out.println("- print students --> to print all the students details");
        System.out.println("- courses --> to print the courses list");
        System.out.println("- add new student --> to add new student to the list");
        System.out.println("- create course --> to create new course");
        System.out.println("- exit or 0 --> when you finish");
        System.out.println("--------------------");
    }
}
