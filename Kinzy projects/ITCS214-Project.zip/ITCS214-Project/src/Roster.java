import java.util.LinkedList;
public class Roster<E> {
    private LinkedList<Student> StudentList;
    private int StudentLsize = 0;
    public Roster()
    {

        StudentList=new LinkedList<Student>();
        StudentLsize=0;
    }
    public boolean addStudent(Student S1){

        for(int i =0; i<StudentList.size();i++)
        {
            if(StudentList.get(i).equals(S1))
            {
                return false;
            }
        }
        StudentList.add(S1);
        StudentLsize++;
        return true;
    }
    public boolean deleteStudent(long ID)
    {
        if(searchStudent(ID)!=-1)
        {
            StudentList.remove(searchStudent(ID));
            StudentLsize--;
            return true;
        }
        else
            return false;
    }
    public int searchStudent (long ID)
    {
        if(isEmpty())
        {
            return -1;
        }
        for(int i=0; i<StudentList.size();i++)
        {
            if(StudentList.get(i).getIdNum()==ID)
            {
                return i;
            }
        }
        return -1;
    }
    public boolean isEmpty ()
    {
        if(StudentList.size()==0)
        {
            return true;
        }else
            return false;
    }
    public int listSize()
    {

        return StudentLsize;
    }
    public boolean addCourse (Course CR1, long ID)
    {
        int index = searchStudent(ID);
        if(index!=-1)
        {
            int CreditSum=0;
            for(int i =0; i<StudentList.get(index).getCoursesRegistered().size();i++)
            {
                if(StudentList.get(index).getCoursesRegistered().get(i).getCourseNum().equalsIgnoreCase(CR1.getCourseNum()))
                {
                    return false;
                }
                CreditSum += StudentList.get(index).getCoursesRegistered().get(i).getCredits();
            }
            CreditSum+=CR1.getCredits();
            if(CreditSum>18)
                return false;
            StudentList.get(index).getCoursesRegistered().add(CR1);
            return true;
        }
        return false;
    }
    public boolean DeleteCourse (Course CR1, long ID)
    {
        int index = searchStudent(ID);
            if(index!=-1)
            {
                if(StudentList.get(index).getCoursesRegistered().contains(CR1))
                {
                    StudentList.get(index).getCoursesRegistered().remove(CR1);
                    return true;
                }
            }
        return false;
    }
    public void printStudentDetails (long ID)
    {
        int index = searchStudent(ID);
        if(index!=-1)
        {
            System.out.print("ID num : "+StudentList.get(index).getIdNum()+ "\n Name : ");
            System.out.println(StudentList.get(index).getFirstName()+ " " +StudentList.get(index).getLastName());
            System.out.println("Gender : "+StudentList.get(index).getGender());
            System.out.println("Email : "+StudentList.get(index).getEmail());
            for (int j = 0; j<StudentList.get(index).getCoursesRegistered().size();j++)
            {
                System.out.println("Course "+(j+1)+": ");
                System.out.println(StudentList.get(index).getCoursesRegistered().get(j).toString());
            }
        }
    }


}
