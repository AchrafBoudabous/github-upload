
public class Course
{
    private String courseNum;
    private String courseName;
    private int credits;
    private int section;

    public Course ()
    {
        this.courseNum="Null";
        this.courseName="Null";
        this.credits=0;
        this.section=0;
    }
    public Course(String Ncoursnum,String Ncoursname,int Ncredits,int Nsection)
    {
        courseNum = Ncoursnum;
        courseName = Ncoursname;
        credits = Ncredits;
        section = Nsection;
    }

    public String getCourseNum()
    {
        return courseNum;
    }

    public void setCourseNum(String courseNum) {
        this.courseNum = courseNum;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public int getSection() {
        return section;
    }

    public void setSection(int section) {
        this.section = section;
    }

    public String toString()
    {
        return "Course {" +
                " code : '" + courseNum + '\'' +
                ", course Name : '" + courseName + '\'' +
                ", credits : " + credits +
                ", section : " + section +
                '}'+"\n" ;
    }
    public boolean isEquals(Course CR1){
        if(this.courseName.equals(CR1.courseName)&&this.courseNum==CR1.courseNum&&this.credits==CR1.credits&&this.section==CR1.section){
            return true;
        }else
            return false;

    }

}
